# `nordeacsv`

Program used for formatting .CSV files  
